/* 
  Importante: 
  No modificar ni el nombre ni los argumetos que reciben las funciones, sólo deben escribir
  código dentro de las funciones ya definidas. 
  No comentar la funcion 
*/
function mayorMenosMenor(arr) {
  // Obtener del array "arr" el número mayor y el menor. Devuelve la resta entre los mismos
  // NOTA: No utilizar los métodos "min" y "max" de "Math".
  //
  // Tu código:
  let numeroMayor = arr[0];
  let numeroMenor = arr[0];
  let resta = 0;

  for (let i=0; i < arr.length; i++) {
    if (arr[i] > numeroMayor) {
      numeroMayor = arr[i];
    } else if (arr[i] < numeroMenor) {
      numeroMenor = arr[i];
    }
  }
  return numeroMayor - numeroMenor;
};
// No modifiques nada debajo de esta linea //

module.exports = mayorMenosMenor